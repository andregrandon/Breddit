from django.apps import AppConfig


class BitPostsConfig(AppConfig):
    name = 'bit_posts'
