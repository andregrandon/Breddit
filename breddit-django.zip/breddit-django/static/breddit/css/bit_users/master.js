
// Initialize Bootstrap components
$(document).ready(function () {
    // Initialize Bootstrap Carousel
    $('#about-carousel').carousel();
});