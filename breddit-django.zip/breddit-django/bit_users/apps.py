from django.apps import AppConfig


class BitUsersConfig(AppConfig):
    name = 'bit_users'
